<?php
/**
 * Bohudur API Client
 *
 * Handles communication with the Bohudur API for payment processing.
 *
 * @package Bohudur\Tutor\Api
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Api;

/**
 * Class ApiClient
 *
 * Provides methods for interacting with the Bohudur payment gateway API.
 *
 * @package Bohudur\Tutor\Api
 * @since   1.0.0
 */
class ApiClient {

    /**
     * API Key for authentication.
     *
     * @since 1.0.0
     * @var   string
     */
    private string $api_key;

    /**
     * Constructor.
     *
     * @since  1.0.0
     * @param  string $api_key API Key for authentication.
     */
    public function __construct(string $api_key) {
        $this->api_key = $api_key;
    }

    /**
     * Create a new payment request.
     *
     * @since  1.0.0
     * @param  array $data Payment request data.
     * @return array Response from the API.
     * @throws ApiException If the API request fails.
     */
    public function createPayment(array $data): array {
        return $this->send_request('create', $data, 'POST');
    }

    /**
     * Verify a payment's status.
     *
     * @since  1.0.0
     * @param  string $paymentkey Payment Key to verify.
     * @return array Response from the API.
     * @throws ApiException If the API request fails.
     */
    public function executePayment(string $paymentkey): array {
        return $this->send_request(
            'execute',
            array('paymentkey' => $paymentkey),
            'POST'
        );
    }

    /**
     * Send request to the API.
     *
     * @since  1.0.0
     * @param  string $endpoint API endpoint path.
     * @param  array  $data     Request data.
     * @param  string $method   HTTP method to use.
     * @return array Response from the API.
     * @throws ApiException If the request fails.
     */
    private function send_request(string $endpoint, array $data = array(), string $method = 'POST'): array {
        $url = 'https://request.bohudur.one/'. $endpoint . '/';

        $args = array(
            'method'  => $method,
            'timeout' => 45,
            'headers' => array(
                'AH-BOHUDUR-API-KEY' => $this->api_key,
                'Content-Type'       => 'application/json',
                'Accept'             => 'application/json',
            ),
        );

        if (in_array($method, array('POST', 'PUT'), true)) {
            $args['body'] = wp_json_encode($data);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            throw new ApiException(esc_html($response->get_error_message()));
        }

        $body   = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ApiException(esc_html__('Invalid JSON response from API', 'tutor-bohudur'));
        }

        if (!empty($result['status']) && $result['status'] == 'failed') {
            throw new ApiException(esc_html($result['message']));
        }

        return $result;
    }
}