<?php
/**
 * Bohudur API Exception
 *
 * This file defines the custom exception class for handling API-related errors
 * in the Bohudur Tutor integration.
 *
 * @package Bohudur\Tutor\Api
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Api;

/**
 * Class ApiException
 *
 * Custom exception class for handling Bohudur API specific errors.
 * Extends the PHP base Exception class to provide specialized error
 * handling for API-related operations.
 *
 * @package Bohudur\Tutor\Api
 * @since   1.0.0
 */
class ApiException extends \Exception {
}
