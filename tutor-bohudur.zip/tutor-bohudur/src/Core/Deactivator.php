<?php
/**
 * Plugin Deactivator
 *
 * This class handles the deactivation process of the Bohudur Tutor LMS integration,
 * ensuring proper cleanup of plugin-specific settings and rules.
 *
 * @package Bohudur\Tutor
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Core;

/**
 * Class Deactivator
 *
 * Handles plugin deactivation tasks and cleanup operations.
 *
 * @package Bohudur\Tutor\Core
 * @since   1.0.0
 */
class Deactivator {

    /**
     * Plugin deactivation handler.
     *
     * Performs necessary cleanup tasks during plugin deactivation,
     * including flushing rewrite rules and triggering deactivation hooks.
     *
     * @since  1.0.0
     * @return void
     */
    public function deactivate(): void {
        flush_rewrite_rules();

        do_action('tutor_bohudur_deactivated');
    }
}