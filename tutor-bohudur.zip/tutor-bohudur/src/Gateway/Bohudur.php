<?php
/**
 * Bohudur Payment Class
 *
 * Handles payment processing functionality
 *
 * @package Bohudur\Tutor\Gateway
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Gateway;

use ErrorException;
use Ollyo\PaymentHub\Core\Payment\BasePayment;
use Ollyo\PaymentHub\Core\Support\Arr;
use Ollyo\PaymentHub\Core\Support\System;
use Throwable;
use Bohudur\Tutor\Api\ApiClient;
use Bohudur\Tutor\Api\ApiException;

class Bohudur extends BasePayment {
    /**
     * Handles payment processing operations
     * 
     * @since 1.0.0
     * @var ApiClient
     */
    protected ApiClient $client;
    
    /**
    	 * Check required configurations
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return bool
    	 */
    	 
    public function check(): bool {
        $required_keys = Arr::make(['api_key']);
          
        $are_required_keys_ok = $required_keys->every(function ($key) {
            return $this->config->has($key) && !empty($this->config->get($key));
        });
          
        return $are_required_keys_ok;
    }
    
    	/**
    	 * Setup payment gateway
    	 *
    	 * @since 1.0.0
    	 *
    	 * @throws Throwable If client initialization fails.
    	 */
    public function setup(): void {
        try {
            $this->client = new ApiClient( $this->config->get('api_key'));
        } catch ( Throwable $error ) {
            throw $error;
        }
    }
    
    	/**
    	 * Set payment data
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param object $data Payment data.
    	 *
    	 * @throws Throwable If data structuring fails.
    	 */
    public function setData( $data ): void {
        try {
            $structured_data = $this->prepareData( $data );
            parent::setData( $structured_data );
        } catch( Throwable $error ) {
            throw $error;
        }
    }
    
    /**
    	 * Prepare payment data
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param object $data Raw payment data.
    	 *
    	 * @return array
    	 */
    
    private function prepareData( $data ) {
        $currency = $data->currency->code;
        
        $rate = (float) $this->config->get( 'currency_rate' );
        $currency_rate = 1;
        
        if($currency != 'BDT'){
            if($rate != 0 || $rate != ''){
                $currency_rate = $rate;
            }else{
                $currency_rate = 0;
            }
        }
        
        $data_set = array(
            'fullname'       => $data->billing_address->name ?? 'Default Name',
            'email'          => $data->billing_address->email,
            'amount'         => $data->total_price,
            'return_type'    => 'Q',
            'currency'       => $currency,
            'currency_value' => $currency_rate,
            'metadata'       => array(
                'order_id'     => $data->order_id,
                'redirect_url' => $this->config->get( 'success_url' ),
            ),
            'redirect_url' => $this->config->get( 'webhook_url' ),
            'cancelled_url'   => $this->config->get( 'cancel_url' ),
        );
        
        return $data_set;
    }
    
    /**
    	 * Create payment request
    	 *
    	 * @since 1.0.0
    	 *
    	 * @throws ApiException    If payment gateway returns an error.
    	 * @throws ErrorException If payment creation fails.
    	 */
    public function createPayment() {
        try {
            $response = $this->client->createPayment( $this->getData() );
            if (isset($response['payment_url'])) {
                wp_redirect( $response['payment_url'] );
                exit;
            }
            
            if (isset($response['message'])) {
                throw new ApiException( sprintf( esc_html__( 'Gateway Error: %s', 'tutor-bohudur' ), esc_html( $response['message'] ) ) );
            }
            
            throw new ApiException( esc_html__( 'Failed to get payment URL from Bohudur', 'tutor-bohudur' ) );
        } catch (ApiException $error){
            throw new ErrorException( esc_html( $error->getMessage() ) );
            sprintf(
                esc_html__( 'Payment verification failed: %s', 'tutor-bohudur' ),
                esc_html( $error->getMessage() )
            );
        }
    }
    
    	/**
    	 * Execute payment and prepare order data
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param object $payload Payment payload.
    	 *
    	 * @return object
    	 *
    	 * @throws Throwable|ApiException If payment validation fails.
    	 */
    public function verifyAndCreateOrderData( object $payload ): object {
        try {
            $paymentkey = $this->extractPaymentKey( $payload );
            $response   = $this->validatePaymentResponse( $paymentkey );
            return $this->prepareOrderData( $response );
        } catch (Throwable $error){
            throw new ApiException(
                sprintf(
                    esc_html__( 'Payment verification failed: %s', 'tutor-bohudur' ),
                    esc_html( $error->getMessage() )
                )
            );
        }
    }
    
    	/**
    	 * Extract Payment Key from payload
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param object $payload Payment payload.
    	 *
    	 * @return string
    	 * @throws ApiException If Payment Key is missing.
    	 */
    private function extractPaymentKey(object $payload): string {
        if (!empty($payload->get['payment_key'])) {
            return sanitize_text_field($payload->get['payment_key']);
        }
        
        if (!empty($payload->stream)) {
            $stream_data = json_decode($payload->stream, true);
    
            if (!empty($stream_data['payment_key'])) {
                return sanitize_text_field($stream_data['payment_key']);
            }
        }
        
        throw new ApiException(
            esc_html__('Payment not found in the request', 'tutor-bohudur')
        );
    }

    /**
    	 * Validate payment response
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param string $paymentkey Payment Key
    	 *
    	 * @return array
    	 * @throws ApiException If validation fails.
    	 */
    private function validatePaymentResponse(string $paymentkey): array {
        $response = $this->client->executePayment($paymentkey);
        
        if (empty($response) || !is_array($response)) {
            throw new ApiException(
                esc_html__('Invalid response from payment gateway', 'tutor-bohudur')
            );
        }
        
        if(isset($response['status']) || isset($response['responseCode']) || isset($response['message'])){
            throw new ApiException(
                sprintf(
                    esc_html__($response['message'], 'tutor-bohudur'),
                    esc_html($field)
                )
            );
        }else if(isset($response['Status']) && isset($response['Metadata'])){
            $metadata = json_decode($response['Metadata'], true);
            if(!isset($metadata['order_id']) || !isset($metadata['redirect_url'])){
                throw new ApiException(
                    esc_html__('Missing required metadata in response', 'tutor-bohudur')
                );
            }
        }else{
            throw new ApiException(
                esc_html__('Missing required in response', 'tutor-bohudur')
            );
        }
        
        return $response;
    }

    
    	/**
    	 * Prepare order data from response
    	 *
    	 * @since 1.0.0
    	 *
    	 * @param array $response Payment gateway response.
    	 *
    	 * @return object
    	 */
    private function prepareOrderData(array $response): object {
        $return_data = System::defaultOrderData();
        
        $status_map = [
            'ERROR'     => 'failed',
            'EXECUTED'  => 'paid',
            'PENDING'   => 'pending',
        ];
        
        $payment_status = '';
        if(isset($response['Status']) && $response['Status'] == 'EXECUTED'){
            $payment_status = 'EXECUTED';
        }else if(isset($response['responseCode']) && $response['responseCode'] == 808){
            $payment_status = 'PENDING';
        }else{
            $payment_status = 'ERROR';
        }
        
        $metadata = json_decode($response['Metadata'], true);
        $return_data->id             = sanitize_text_field($metadata['order_id']);
        $return_data->payment_status = $status_map[$payment_status];
        $return_data->transaction_id = isset($response['Transaction ID']) ? sanitize_text_field($response['Transaction ID']) : 'NONE';
        
        $return_data->redirectUrl = esc_url_raw($metadata['redirect_url']);
        
        $return_data->payment_error_reason = '';
        $return_data->payment_payload      = $response;
        $return_data->fees                 = '';
        $return_data->earnings             = '';
        
        return $return_data;
    }
}