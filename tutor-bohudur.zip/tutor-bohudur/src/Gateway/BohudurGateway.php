<?php
/**
 * Bohudur Gateway Class
 *
 * Handles Bohudur gateway functionality.
 *
 * @package Bohudur\Tutor\Gateway
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Gateway;

use Tutor\PaymentGateways\GatewayBase;

/**
 * Handles Bohudur payment integration for Tutor LMS.
 *
 * @since 1.0.0
 */
class BohudurGateway extends GatewayBase {
    /**
    	 * Gateway directory name.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    private $dir_name = 'bohudur';
    /**
    	 * Gateway config class.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    private $config_class = BohudurConfig::class;
    
    	/**
    	 * Payment processing class.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    private $payment_class = Bohudur::class;
    
    	/**
    	 * Get gateway directory name.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    public function get_root_dir_name(): string {
        return $this->dir_name;
    	}
    /**
    	 * Get payment class name.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    	public function get_payment_class(): string {
    	    return $this->payment_class;
    	}
    
    	/**
    	 * Get config class name.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    	public function get_config_class(): string {
    	    return $this->config_class;
    	}
    
    	/**
    	 * Get autoload file path.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    	public static function get_autoload_file(): string {
    	    return TUTOR_BOHUDUR_DIR . '/vendor/autoload.php';
    	}
}