<?php
/**
 * Bohudur Config Class
 *
 * Handles configuration management for the Bohudur gateway.
 *
 * @package Bohudur\Tutor\Gateway
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Gateway;

use Ollyo\PaymentHub\Contracts\Payment\ConfigContract;
use Ollyo\PaymentHub\Core\Payment\BaseConfig;
use Tutor\Ecommerce\Settings;
use Tutor\PaymentGateways\Configs\PaymentUrlsTrait;

/**
 * Manages Bohudur gateway configuration.
 *
 * @since 1.0.0
 */
class BohudurConfig extends BaseConfig implements ConfigContract {
    use PaymentUrlsTrait;
    
    /**
    	 * API Key for the gateway.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    	private $api_key;
    
    /**
    	 * Custom currency rate for the gateway.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    private float $currency_rate;
    
    /**
    	 * Gateway name.
    	 *
    	 * @since 1.0.0
    	 * @var string
    	 */
    	protected $name = 'bohudur';
    
    /**
    	 * Initialize configuration settings.
    	 *
    	 * @since 1.0.0
    	 */
    	public function __construct() {
    	    parent::__construct();
    	    
    	    $settings    = Settings::get_payment_gateway_settings( 'bohudur' );
    	    $config_keys = array_keys( $this->get_bohudur_config_keys() );
    	    
    	    foreach ( $config_keys as $key ) {
    	        $this->$key = $this->get_field_value( $settings, $key );
    	    }
    	}
    
    /**
    	 * Get API Key.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    	private function getApiKey(): string {
    	    return $this->api_key;
    	}
    
    /**
    	 * Get Currency rate
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return string
    	 */
    private function getCurrencyRate(): float {
    	    return (float) $this->currency_rate;
    	}
    
    /**
    	 * Check if gateway is configured.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return bool
    	 */
    	public function is_configured(): bool {
    	    return (bool) ( $this->api_key && $this->currency_rate);
    	}
    
    /**
    	 * Get configuration field keys.
    	 *
    	 * @since 1.0.0
    	 *
    	 * @return array
    	 */
    	private function get_bohudur_config_keys(): array {
    	    return array(
    	       'api_key'       => 'secret_key',
    	       'currency_rate' => 'currency_rate',
    	    );
    	}
    
    /**
    	 * Create gateway configuration.
    	 *
    	 * @since 1.0.0
    	 * @return void
    	 */
    	public function createConfig(): void {
    	    parent::createConfig();
    	    
    	    $config = array(
            'api_key'       => $this->getApiKey(),
            'currency_rate' => $this->getCurrencyRate(),
    	    );
    	    
    	    $this->updateConfig( $config );
    	}
}