<?php
/**
 * Init Tutor Class
 *
 * Handles Tutor class initialization.
 *
 * @package Bohudur\Tutor\Gateway
 * @since   1.0.0
 */

namespace Bohudur\Tutor\Gateway;

use Bohudur\Tutor\Gateway\BohudurConfig;
use Bohudur\Tutor\Gateway\BohudurGateway;
use Tutor\Ecommerce\Settings;

/**
 * Initialize Tutor Gateway Integration
 *
 * @since 1.0.0
 */
final class InitTutor
{
    /**
     * Register hooks and filters.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        add_filter('tutor_gateways_with_class', __CLASS__ . '::paymentGatewaysWithRef', 10, 2);
        add_filter('tutor_payment_gateways_with_class', __CLASS__ . '::filterPaymentGateways');
        add_filter('tutor_payment_gateways', array($this, 'addPaymentMethod'), 100);
    }

    /**
     * Get payment gateways with reference class.
     *
     * @since 1.0.0
     *
     * @param array  $value   Gateway with ref class.
     * @param string $gateway Payment gateway name.
     * @return array
     */
    public static function paymentGatewaysWithRef($value, $gateway)
    {
        $arr = array(
            'bohudur' => array(
                'gateway_class' => BohudurGateway::class,
                'config_class'  => BohudurConfig::class,
            ),
        );

        if (isset($arr[$gateway])) {
            $value[$gateway] = $arr[$gateway];
        }

        return $value;
    }

    /**
     * Filter payment gateways.
     *
     * @since 1.0.0
     *
     * @param array $gateways Tutor payment gateways.
     * @return array
     */
    public static function filterPaymentGateways($gateways)
    {
        $arr = array(
            'bohudur' => array(
                'gateway_class' => BohudurGateway::class,
                'config_class'  => BohudurConfig::class,
            ),
        );

        $gateways = $gateways + $arr;

        return $gateways;
    }

    /**
     * Add Bohudur payment method.
     *
     * @since 1.0.0
     *
     * @param array $methods Tutor existing payment methods.
     * @return array
     */
    public function addPaymentMethod($methods)
    {
        $settings = Settings::get_payment_gateway_settings('bohudur');
        $url = plugin_dir_url(__FILE__) . 'logo.png';
        
        $bohudur_payment_method = array(
            'name'                 => 'bohudur',
            'label'                => isset($settings['fields'][0]['value'])
                ? $settings['fields'][0]['value']
                : 'Bohudur Payments',
            'is_installed'         => true,
            'is_active'            => true,
            'icon'                 => $url,
            'support_subscription' => true,
            'fields'               => array(
                array(
                    'name'  => 'display_name',
                    'type'  => 'text',
                    'label' => 'Display Name',
                    'value' => 'Bohudur Payments',
                ),
                array(
                    'name'  => 'api_key',
                    'type'  => 'secret_key',
                    'label' => 'API Key',
                    'value' => '',
                ),
                array(
                    'name'  => 'currency_rate',
                    'type'  => 'number',
                    'label' => 'Currency Rate',
                    'value' => '0',
                ),
            ),
        );

        $methods[] = $bohudur_payment_method;

        return $methods;
    }
}
