<?php
/**
 * Plugin Name: Bohudur - Tutor LMS
 * Plugin URI: https://github.com/BohudurOne/TutorLMS
 * Description: Integrate Bohudur with Tutor LMS Easily.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Bohudur
 * Author URI: https://bohudur.one
 * License: MIT
 * License URI: https://opensource.org/licenses/MIT
 * Text Domain: tutor-bohudur
 * Domain Path: /languages
 *
 * @package Bohudur\Tutor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Plugin constants.
 */
define( 'TUTOR_BOHUDUR_FILE', __FILE__ );
define( 'TUTOR_BOHUDUR_DIR', dirname( TUTOR_BOHUDUR_FILE ) );

/**
 * Autoloader.
 */
require TUTOR_BOHUDUR_DIR . '/vendor/autoload.php';

/**
 * Initialize plugin.
 */
if ( class_exists( \Bohudur\Tutor\Core\Plugin::class ) ) {
	\Bohudur\Tutor\Core\Plugin::run();
}
new \Bohudur\Tutor\Gateway\InitTutor();